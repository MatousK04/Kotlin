package com.example.lifecyclehandlers

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Text("check the logcat for messages on state changes")
        }

        Log.i("lifecycle handlers", "onCreate() called")
    }

    override fun onDestroy()
    {
        super.onDestroy()
        Log.i("lifecycle-handlers", "onDestroy() called")
    }

    override fun onResume()
    {
        super.onResume()
        Log.i("lifecycle-handlers", "onResume() called")
    }

    override fun onPause()
    {
        super.onPause()
        Log.i("lifecycle-handlers", "onPause() called")
    }

    override fun onStop()
    {
        super.onStop()
        Log.i("lifecycle-handlers", "onStop() called")
    }

    override fun onStart()
    {
        super.onStart()
        Log.i("lifecycle-handlers" , "onStart() called")
    }



}
