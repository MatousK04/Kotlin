package com.example.lab5part3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateOf

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Column {
                Text("Selected tab is ${tab_titles[selected_tab.value]}")
                ScrollableTabRow(selectedTabIndex = selected_tab.value) {
                    tab_titles.forEachIndexed { index, title ->
                        Tab(
                            onClick = { selected_tab.value = index },
                            selected = selected_tab.value == index,
                            content = {
                                Text("Title")
                            })
                    }
                }
                Text("This is the ${tab_titles[selected_tab.value]} tab")
            }
        }
    }
    var tab_titles = listOf("Songs","Artists", "Playlists","Songs","Artists", "Playlists")
    var selected_tab = mutableStateOf(0)
}
