package com.example.canvas

import android.graphics.Canvas
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.math.floor


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Column {
                ticTacToeView(game_state = array)
                {
                    x,y ->
                    placePiece(x,y)
                    updateGameStatus()
                }
                Text("current player is ${player.value}")
                Button(onClick = {
                    resetGame()
                }) {
                    Text("Reset Game")
                }
            }
        }
    }
    private fun placePiece(x: Int, y: Int)
    {
        if(array[x][y] == 0 && player.value == 1)
        {
            array[x][y] = 1
            player.value = 2
        } else if (array[x][y] == 0 && player.value == 2) {
           array[x][y] = 2
           player.value = 1
        }
    }

    private fun resetGame() {
        for(i in 0 until 3)
            for(j in 0 until 3){
                array[i][j] = 0
            }

        player.value = 1
        game_status.value = "Current player is 1"
    }

    private fun updateGameStatus() {
        if(player.value == 1)
            game_status.value = "Current player is 1"
        else if (player.value == 2)
            game_status.value = "Current player is 2"
    }

    private var array = mutableStateListOf<MutableList<Int>>(mutableStateListOf(0,0,0),mutableStateListOf(0,0,0),mutableStateListOf(0,0,0))
    private var player = mutableStateOf(1)
    private var game_status = mutableStateOf("Current player is 1")
}

@Composable
fun ticTacToeView(game_state: MutableList<MutableList<Int>>, onAttemptMove: (x: Int, y: Int) -> Unit)
{
    var width by remember {mutableStateOf(0.0f)}
    var height by remember {mutableStateOf(0.0f)}
    var cell_width by remember {mutableStateOf(0.0f)}
    var cell_height by remember {mutableStateOf(0.0f)}

    Canvas(
        modifier = Modifier
            .aspectRatio((1.0f))
            .pointerInput(key1 = Unit) {
                detectTapGestures(
                    onTap = {
                        var cell_x = floor(it.x / cell_width).toInt()
                        var cell_y = floor(it.y / cell_height).toInt()
                        onAttemptMove(cell_x, cell_y)
                    }
                )
            }
    ) {
        width = size.width
        height = size.height

        cell_width = width / 3.0f
        cell_height = height / 3.0f

        drawRect(color = Color.Black, size = Size(width,height))

        for(i in 1 until 3)
        {
            withTransform(
                {
                    translate(i*cell_width, 0.0f)
                }
            ) {
                drawLine(Color.White, start = Offset(0.0f, 0.0f), end = Offset(0.0f, height))
            }
        }

        for(i in 1 until 3)
        {
            withTransform({
                translate(0.0f, i * cell_height)
            })
            {
                drawLine(Color.White, start = Offset(0.0f,0.0f), end = Offset(width, 0.0f))
            }
        }

        for(i in 0 until 3)
        {
            for(j in 0 until 3)
            {
                if(game_state[i][j] == 1)
                {
                    withTransform({
                        translate(i*cell_width, j*cell_height)
                    })
                    {
                        drawLine(Color.Green, start = Offset(0.0f, 0.0f), end = Offset(cell_width, cell_height))
                        drawLine(Color.Green, start = Offset(cell_width, 0.0f), end = Offset(0.0f,cell_height))
                    }
                } else if (game_state[i][j] == 2)
                {
                    withTransform({
                        translate(i * cell_width, j * cell_height)
                    })
                    {
                        drawOval(color = Color.Red, topLeft = Offset(0.0f,0.0f), size = Size(cell_width, cell_height))
                    }
                }
            }
        }
    }



}
