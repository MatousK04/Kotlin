package com.example.lab4part2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

@ExperimentalMaterial3Api
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Column{
                Text("value of the spinner is ${value.value}")
                spinner(options, value.value)
                {
                    value.value = it
                    println("changed to ${value.value}")
                }
            }
        }
    }
    var options = listOf("Select an option", "First", "Second", "Third")
    var value = mutableStateOf(options[0])
}

@ExperimentalMaterial3Api
@Composable
fun spinner(options:List<String>, selected : String, selectedOption:(String) -> Unit)
{
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = {expanded = it}) {
        TextField(value = selected, onValueChange = {}, readOnly = true, modifier = Modifier.menuAnchor())
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = {expanded = false}) {
            for(i in options.indices)
                DropdownMenuItem(text = {Text(options[i])}, onClick = {selectedOption(options[i]);expanded = false})
        }
    }
}