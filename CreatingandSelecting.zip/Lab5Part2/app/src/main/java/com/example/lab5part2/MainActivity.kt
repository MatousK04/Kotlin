package com.example.lab5part2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction

@ExperimentalFoundationApi
@ExperimentalMaterial3Api
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Column{
                Text("clicked item ${last_clicked.value}")
                Text("long clicked item ${last_long_clicked.value}")
                TextField(value = user_input.value, onValueChange = {user_input.value = it}, keyboardActions = KeyboardActions(onDone = {
                    items_list.add(user_input.value)
                }), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done))
                verticalList(items_list, {last_clicked.value = it}, {last_long_clicked.value = it})
            }
        }
    }
    var last_clicked = mutableStateOf(0)
    var last_long_clicked = mutableStateOf(0)
    var items_list = mutableStateListOf<String>()
    var user_input = mutableStateOf("add an item here")

}

@ExperimentalFoundationApi
@ExperimentalMaterial3Api
@Composable
fun verticalList(items_list: MutableList<String>, onStateChanged: (Int) -> Unit, onLongClick: (Int) -> Unit){
    LazyColumn {
        for(i in 0 until items_list.size){
            item{
                ListItem(
                    headlineContent = {Text("entered item $i")},
                    supportingContent = {Text(text = items_list[i])},
                    modifier = Modifier.combinedClickable(
                        onClick = {
                            onStateChanged(i)
                        },
                        onLongClick = {
                            onLongClick(i)
                        }
                    )
                )
            }
        }
    }
}