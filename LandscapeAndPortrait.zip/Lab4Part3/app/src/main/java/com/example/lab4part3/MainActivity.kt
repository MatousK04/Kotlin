package com.example.lab4part3

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var config: Configuration = resources.configuration
        setContent {
            if(config.orientation == Configuration.ORIENTATION_PORTRAIT)
                Text("View is portrait")
            else
                Text("View is landscape")
        }
    }
}

