package com.example.lab5part1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier

@ExperimentalMaterial3Api
@ExperimentalFoundationApi
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
           Column{
               Text("clicked item ${last_clicked.value}")
               Text("long clicked item ${last_long_clicked.value}")
               verticalList({last_clicked.value = it}, {last_long_clicked.value = it})
           }
        }

    }
    var last_clicked = mutableStateOf(0)
    var last_long_clicked = mutableStateOf(0)
}
@ExperimentalFoundationApi
@ExperimentalMaterial3Api
@Composable
fun verticalList(onStateChanged: (Int) -> Unit, onLongClick:(Int)->Unit) {
    LazyColumn{
        for(i in 0 until 100) {
            item{
                ListItem(
                    headlineContent = {Text("Vertical")},
                    supportingContent = {Text(text = "Row item $i")},
                    modifier = Modifier.combinedClickable(
                        onClick = {
                            onStateChanged(i)
                        },
                        onLongClick = {
                            onLongClick(i)
                        }
                    )
                )
            }
        }
    }
}