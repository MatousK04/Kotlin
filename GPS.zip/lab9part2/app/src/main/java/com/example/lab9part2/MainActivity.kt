package com.example.lab9part2

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresPermission
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.Composable
import androidx.core.content.ContextCompat


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Column{
                Text(text = latitude.value)
                Text(text = longitude.value)
                Button(onClick = {
                    if(started_tracking.value)
                        removeLocationListener()
                    else {
                        addLocationListener()
                    }
                }) {
                    if(started_tracking.value)
                        Text("Stop GPS tracking")
                    else
                        Text("Start GPS tracking")
                }

                val permission_launcher =
                    rememberLauncherForActivityResult(contract = ActivityResultContracts.RequestMultiplePermissions()) {
                        if(!it.values.reduce {acc, next -> acc && next})
                            denied_gps.value = true
                        requested_gps.value = false
                    }
                if(requested_gps.value)
                {
                    permission_launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }
                if (denied_gps.value) {
                    showWhyNotificationNeeded {
                        denied_gps.value = false
                    }
                }
            }
        }
    }

    private fun addLocationListener()
    {
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requested_gps.value = true
            return
        }

        var lm : LocationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 0f, location_listener)

        started_tracking.value = true

    }

    private fun removeLocationListener()
    {
        var lm : LocationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm.removeUpdates(location_listener)
        latitude.value = "Latitude: N/A"
        longitude.value = "Longitude: N/A"
    }
    var location_listener: LocationListener = LocationListener {
        latitude.value = "Latitude: ${it.latitude}"
        longitude.value = "Longitude: ${it.longitude}"
    }
    var latitude = mutableStateOf("Latitude: N/A")
    var longitude = mutableStateOf("Longitude: N/A")

    var requested_gps = mutableStateOf(false)
    var denied_gps = mutableStateOf(false)

    var started_tracking = mutableStateOf(false)

    @Composable
    fun showWhyNotificationNeeded(onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Location Permission") },
            text = { Text("This app requires access to coarse and fine location permissions so it can track your location.") },
            confirmButton = {
                TextButton(onClick = onDismiss) {
                    Text("Dismiss")
                }
            }
        )
    }

}
