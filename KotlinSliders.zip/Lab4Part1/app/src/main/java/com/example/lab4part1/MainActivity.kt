package com.example.lab4part1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity()
{
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContent {
            Column {
                basicTextCard(title = "hello", subtext = "hello world")
                basicTextCard(title = "bye", subtext = "goodbye world")
                cardWithButton(title = "action 0", subtext = "click the button", index = 0) {
                    println("card with button $it clicked")
                }
                cardWithButton(title="action 1", subtext = "click the button", index = 1) {
                    println("card with button $it clicked")
                }
                HorizontalDivider()
                Text("value of slider is ${slider_value.value}")
                Slider(value = slider_value.value, onValueChange = {slider_value.value = it }, valueRange = 0.0f .. 5.0f)
                HorizontalDivider()
                Text("value of range is slider is ${range_slider_value.value}")
                RangeSlider(value = range_slider_value.value, onValueChange = {range_slider_value.value = it},valueRange = 0.0f .. 5.0f)
            }
        }

    }
    var slider_value = mutableStateOf(0.0f)
    var range_slider_value = mutableStateOf(0.0f .. 1.0f)

}


@Composable
fun basicTextCard(title : String, subtext : String)
{
    val padding = Modifier.padding(5.dp)
    Card(modifier = padding)
    {
        Column {
            Text(text = title, modifier = padding, fontSize = 20.sp)
            Text(text = subtext, modifier = padding)
        }
    }
}

@Composable
fun cardWithButton(title: String, subtext: String, index : Int, onStateChanged:(Int) -> Unit)
{
    val padding = Modifier.padding(5.dp)
    Card(modifier = padding){
        Column{
            basicTextCard(title=title, subtext = subtext)
            Button(onClick = {onStateChanged(index)}){
                Text("Click me")
            }
        }
    }
}

