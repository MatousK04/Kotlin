package com.example.lab9

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.foundation.layout.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Column{
                TextButton(onClick = {triggerNotification()}) {
                    Text("Trigger Notification")
                }
            }

            val permission_launcher = rememberLauncherForActivityResult(contract = ActivityResultContracts.RequestPermission()) {
                if(!it)
                    denied_notification.value = true
                requested_notification.value = false
            }
            if(requested_notification.value)
                permission_launcher.launch(Manifest.permission.POST_NOTIFICATIONS)

            if(denied_notification.value)
            {
                showWhyNotificationNeeded{
                    denied_notification.value = false
                }
            }
        }
    }
    private fun triggerNotification()
    {
        var nm: NotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            val nc = NotificationChannel(
                "MY_CHANNEL_ID",
                "My Notification",
                NotificationManager.IMPORTANCE_DEFAULT
            )
        }

        var nb: NotificationCompat.Builder = NotificationCompat.Builder(this,"MY_CHANNEL_ID")
        nb.setDefaults(Notification.DEFAULT_ALL)
        nb.setWhen(System.currentTimeMillis())
        nb.setSmallIcon(R.mipmap.ic_launcher)
        nb.setTicker("My notification ticket text")
        nb.setContentTitle("The long text of the notification itself")
        nb.setContentInfo("The content info text")

        if(ContextCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED)
            nm.notify(1,nb.build())
        else
            requested_notification.value = true
    }


    @Composable
    fun showWhyNotificationNeeded(onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Notification Permission") },
            text = { Text("This app requires notification permission in order to show notifications when triggered.") },
            confirmButton = {
                TextButton(onClick = onDismiss) {
                    Text("Dismiss")
                }
            }
        )
    }
}
var requested_notification = mutableStateOf(false)
var denied_notification = mutableStateOf(false)


